/************************************
/* main.ts
 * This is the RDL2 browser
 * belongs at address http://data.15926.org/rdl
 * By Onno Paap
 * 21 Nov 2021
 * onno.paap@protonmail.com
 * License: MIT
 * how to compile:
 
cd "/home/onno/SynologyDrive/repos/15926browser(TypeScript)/20240104T1000.data.15926.org/var/www/data.15926.org/public_html/15926browser/js/"
tsc -t es5 main.ts
 
 ***********************************/

declare var $: any;
declare var windows: any;

var config, temp, sparql, writer, command : any;

interface IConfig {
	endpoint: string;
	endpoints: any;
	includedeprecated: boolean;
	includeprovenance: boolean;
	searchLiteral: boolean;
}
class Config implements IConfig {  
	settings = {
		// CHANGE THE REAL LOCATION OF THE BROWSER ONLY IN THESE 2 SETTINGS
	    defaultEndpoint : 'https://data.15926.org/rdl',
	    queryAllEndpoint : 'https://data.15926.org/sparql',
	}
	private _endpoint: string;

	get endpoint(): string {return this._endpoint;}
	set endpoint(http: string) {
		this._endpoint=http;
	}

	private _includedeprecated: boolean;
	get includedeprecated(): boolean {return this._includedeprecated;}
	set includedeprecated(status: boolean) {
		this._includedeprecated = status;
	}

	private _includeprovenance: boolean;
	get includeprovenance(): boolean {return this._includeprovenance;}
	set includeprovenance(status: boolean) {
		this._includeprovenance = status;
	}

	private _searchLiteral: boolean;
	get searchLiteral(): boolean {return this._searchLiteral;}
	set searchLiteral(status: boolean) {
		this._searchLiteral = status;
	}

	get endpoints() {return this._endpoints;}
	
	constructor() {
		//if not given in the current address, use the default endpoint
		if (this._endpoint==undefined) this._endpoint = this.settings.defaultEndpoint;

		// define the includedeprecated as false
		if (this._includedeprecated==undefined) this._includedeprecated = false;

		// define the includeprovenance as false
		if (this._includeprovenance==undefined) this._includeprovenance = false;
		
		// define the searchLiteral as false
		if (this._searchLiteral==undefined) this._searchLiteral = false;
	}
	
	private _namespaces =
	[ ["cfihos:", "http://data.15926.org/cfihos/"]
	, ["commodity:", "http://data.15926.org/commodity/"]
	, ["dawgt:", "http://www.w3.org/2001/sw/DataAccess/tests/test-dawg#"]
	, ["dbpedia:", "http://dbpedia.org/resource/"]
	, ["dbpprop:", "http://dbpedia.org/property/"]
	, ["dc:", "http://purl.org/dc/elements/1.1/"]
	, ["dcterms:", "http://purl.org/dc/terms/"]
	, ["dm:", "http://data.posccaesar.org/dm/"]
	, ["dm:", "http://data.15926.org/dm/"]
	, ["fn:", "http://www.w3.org/2005/xpath-functions#"]
	, ["fn:", "http://www.w3.org/2005/xpath-functions/#"]
	, ["foaf:", "http://xmlns.com/foaf/0.1/"]
	, ["geo:", "http://www.w3.org/2003/01/geo/wgs84_pos#"]
	, ["go:", "http://purl.org/obo/owl/GO#"]
	, ["math:", "http://www.w3.org/2000/10/swap/math#"]
	, ["mesh:", "http://purl.org/commons/record/mesh/"]
	, ["meta:", "http://data.15926.org/meta/"]
	, ["mf:", "http://www.w3.org/2001/sw/DataAccess/tests/test-manifest#"]
	, ["nci:", "http://ncicb.nci.nih.gov/xml/owl/EVS/Thesaurus.owl#"]
	, ["obo:", "http://www.geneontology.org/formats/oboInOwl#"]
	, ["owl:", "http://www.w3.org/2002/07/owl#"]
	, ["p2:", "http://rds.posccaesar.org/2008/02/OWL/ISO-15926-2_2003#"]
	, ["product:", "http://www.buy.com/rss/module/productV2/"]
	, ["protseq:", "http://purl.org/science/protein/bysequence/"]
	, ["prov:", "http://data.15926.org/prov/"]
	, ["rdf:", "http://www.w3.org/1999/02/22-rdf-syntax-ns#"]
	, ["rdfa:", "http://www.w3.org/ns/rdfa#"]
	, ["rdfs:", "http://www.w3.org/2000/01/rdf-schema#"]
	, ["rdl:", "http://data.posccaesar.org/rdl/"]
	, ["skos:", "http://www.w3.org/2004/02/skos/core#"]
	, ["sw:", "http://data.15926.org/sw/"]
	, ["tip:", "http://data.15926.org/tip/"]
	, ["tpl:", "http://data.15926.org/tpl/"]
	, ["xsd:", "http://www.w3.org/2001/XMLSchema#"]
	];
	
	private _endpoints =
	[ ["ALL (federate)","https://data.15926.org/all"]
	, ["aisi","https://data.15926.org/aisi"]
	, ["ansi","https://data.15926.org/ansi"]
	, ["api","https://data.15926.org/api"]
	, ["asme","https://data.15926.org/asme"]
	, ["astm","https://data.15926.org/astm"]
	, ["atex","https://data.15926.org/atex"]
	, ["bs","https://data.15926.org/bs"]	
	, ["cfihos","https://data.15926.org/cfihos"]
	, ["commodity","https://data.15926.org/commodity"]
	, ["din","https://data.15926.org/din"]
	, ["dm","https://data.15926.org/dm"]
	, ["dnv","https://data.15926.org/dnv"]
	, ["edm","https://data.15926.org/edm"]
	, ["en","https://data.15926.org/en"]
	, ["eu","https://data.15926.org/eu"]
	, ["iec","https://data.15926.org/iec"]
	, ["ieee","https://data.15926.org/ieee"]
	, ["iso","https://data.15926.org/iso"]
	, ["ispdm","https://data.15926.org/ispdm"]
	, ["lci","https://data.15926.org/lci"]
	, ["mss","https://data.15926.org/mss"]
	, ["nace","https://data.15926.org/nace"]
	, ["nec","https://data.15926.org/nec"]
	, ["nema","https://data.15926.org/nema"]
	, ["nfpa","https://data.15926.org/nfpa"]
	, ["prov","https://data.15926.org/prov"]
	, ["nor","https://data.15926.org/nor"]
	, ["RDL (Ref data Lib)","https://data.15926.org/rdl"]
	, ["sae","https://data.15926.org/sae"]
	, ["sie","https://data.15926.org/sie"]
	, ["sw","https://data.15926.org/sw"]
	, ["tema","https://data.15926.org/tema"]
	, ["tip","https://data.15926.org/tip"]
	, ["tpl","https://data.15926.org/tpl"]
	, ["twr","https://data.15926.org/twr"]
	, ["uns","https://data.15926.org/uns"]
	, ["wits","https://data.15926.org/wits"]
	];
	
	private _i;

	namespace (uri) {
		for	(this._i = 0; this._i < this._namespaces.length; this._i++) {
			uri=uri.replace(this._namespaces[this._i][1],this._namespaces[this._i][0]);
		}
		return uri;
	}
}


$(document).ready(function () {
    
	config = new Config();
	sparql = new Sparql();
	writer = new Writer();
	command = new Command();

	//if changing an endpoint on the dropdown
	$( "#endpoints" ).change(function() {
		config.endpoint = $("#endpoints").val();
	});

	//activate include deprecated switch
	$("#includedeprecated").prop("checked", config.includedeprecated);
	$("#includedeprecated").click(function( event ) {
		config.includedeprecated = $("#includedeprecated").prop("checked");
	});

	//activate include provenance switch
	$("#includeprovenance").prop("checked", config.includeprovenance);
	$("#includeprovenance").click(function( event ) {
		config.includeprovenance = $("#includeprovenance").prop("checked");
	});
	
	//activate include provenance switch
	$("#searchLiteral").prop("checked", config.searchLiteral);
	$("#searchLiteral").click(function( event ) {
		config.searchLiteral = $("#searchLiteral").prop("checked");
	});
	
	//forward and back history click
	window.onpopstate = function(event) {
		if (event.state==null) {
			command.do ( 'history',  'search', null, null, null );
		} else {
			command.do ( 'history',  event.state.layoutview, event.state.doCommand, event.state.val1, event.state.val2 );
		}
	};
	
	//initialize history state
	window.history.pushState( {query: ''} , '', '' );
	
	//check if this is a direct address to be displayed
	var id = window.location.href;
	if (id.substring(-1) == '/' || id.substring(-1) == '#') {
		id = id.substring(0, id.length - 1);
	}
	//check if the last part of the address is a namespace or something longer, like an ID or a query
	var endp = "";
	for (var i of config.endpoints ) {
		if (i[1] == id.substring(0,i[1].length) ) {
			endp = i[1]; 
		}
	} 
	if (endp.length>5) {
		config.endpoint=endp;
	} else {
		config.endpoint=config.settings.defaultEndpoint;
	}

	if (id.length > endp.length) {
		//so id is not a namespace, now assume its a complete id to be retrieved, e.g. 
		// https://data.15926.org/15926browser?id=http://data.15926.org/rdl/RDS267929
		id = id.replace("https","http");
		id = id.replace("data","data");
		id = id.replace("xyz","org");
		command.do('new', 'object', 'object', id, endp);
	} 

	//endpoints in settings
	var selected = '';
	var stringAfterLastSlash = config.endpoint.substring(config.endpoint.lastIndexOf("/")+1);
	for (var i of config.endpoints ) {
		selected = '';
		if ("https://data.15926.org/" + stringAfterLastSlash==i[1]) {
			selected='selected';
		}
		$("#endpoints").append('<option value="' + i[1] + '" ' + selected + '>' + i[0] + '</option>')
	}

	//activate execute a search
	$("#search").keydown(function( event ) {
	  if ( event.which == 13 ) {
	    event.preventDefault();
	    //run query
	    command.do('new', 'query', 'wildcardquery', command.validate($("#search").val()), config.endpoint);
	  }
	});
	$("#info").click(function( event ) {
	 var info = new Info();
	});

	//put cursor in searchbar
	$('#search').focus();

});


interface ICommand {
}
class Command implements ICommand {
	do (mode: string, layoutview: string, doCommand: string, val1: string, val2: string) {

		if (val1 == undefined) {
			val1 = "";
		} else {
			val1 = val1;
		}

		if (val2 == undefined) {
			val2 = val1.substring(0, val1.lastIndexOf("/"));
		}

			
		if (val1>' ') {

			//push state to history
			if (mode=='new') {
			window.history.pushState( {"layoutview": layoutview, "doCommand": doCommand, "val1": val1, "val2": val2} , '', '' );
			}

			//run a command
			if (doCommand=='wildcardquery') {
				sparql.query = val1;
				//$("#search").val(sparql.query);
				sparql.endpoint = val2;
				writer.tablereset();
				sparql.exec('wildcardtext', 1);
			}
			
			if (doCommand=='object') {
				if (val1.substring(0,4) == "http" && val1.indexOf('15926.org')==-1) {
					// this may be an online linked data
					window.location.href = val1;
				} else {
				//	if (val1.substring(0,4) == "http") {
				//	//		sparql.query = val1.substring(val1.lastIndexOf("/")+1);
				//	//} else {
				//		sparql.query = val1;
				//	}
				//	
				//	if (sparql.endpoint != 'http://data.15926.org/all') { //federated query trumps local query
				//		sparql.endpoint = val2;
				//	}
					writer.tablereset();
					sparql.query = val1;
					sparql.endpoint = val2;
					sparql.exec('title', 1);
					sparql.exec('otherpreds', 2);
					sparql.exec('relationsonto', 3);
				}
			}
		}
	}
	validate(val: string) {

		val = val.split('&').join("&amp;");
		val = val.split('"').join("");
		val = val.split("'").join("&#39;");
		val = val.split('<').join("&lt;");
		val = val.split('>').join("&gt;");

		return val;
	}
}


interface IInfo {
}
class Info implements IInfo {

	constructor() {
		this.info()
	}

	info() {
		var html = `
		<div class="accordion" id="myAccordion">
			<div class="accordion-item">
				<h2 class="accordion-header" id="heading01">
					<button type="button" class="accordion-button" data-bs-toggle="collapse" data-bs-target="#collapse01">
						1. What is this ABOUT?
					</button>									
				</h2>
				<div id="collapse01" class="accordion-collapse collapse show" data-bs-parent="#myAccordion">
					<div class="card-body" style="color:navy;">
						<p>This is the search screen for RDL2.</p>
						<p>RDL stands for Reference Data Library. The RDL is an online Ontology and Thesaurus for the classes that are candidate to be used in the POSC Caesar Library, which in turn will set a core set of that candidate for standardization in ISO 15926-4.</p>
						<p>ISO 15926 is the data exchange and integration standard for the process industry. See this <a href="https://en.wikipedia.org/wiki/ISO_15926">WIKIPEDIA article</a></p>
					</div>
				</div>
			</div>
			<div class="accordion-item">
				<h2 class="accordion-header" id="heading02">
					<button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#collapse02">
						2. How does this WORK?
					</button>
				</h2>
				<div id="collapse02" class="accordion-collapse collapse" data-bs-parent="#myAccordion">
					<div class="card-body" style="color:navy;">
						<p>In the drop down are the named graphs to search in. These are not subject areas, but separated by ownership. RDL is the main graph. It contains the core library; the process plant items and other classes like document types, events, mile stones, etc. There are about 23,000 of these classes. 
						<p>Example classes to search for are PUMP, PIPE, TRANSMITTER, LAYOUT or ENGINEERING. All class names are always singular, never plural. </p>
						<p>There are also subject areas like PIPING and INSTRUMENTATION. Just search for SUBJECT AREA</p>
						<p>There are more than 30 graphs containing more than 70,000 classes. Main ones are:</p>
						<li>RDL - core library</li>
						<li>CFIHOS - the classes from the Capital Factilities Information Handover Spec. See <a href="https://www.jip36-cfihos.org/">IOGP website</a></li>
						<li>DM and LCI - the top of the data model</li>
						<li>IEC - a mapping to the CDD, to make these classes FINDable (try searching: transmitter).</li>
					</div>
				</div>
			</div>
			<div class="accordion-item">
				<h2 class="accordion-header" id="heading03">
					<button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#collapse03">
						3. I spotted a problem / want to add a class / need to add a hundred classes for my process plant type?
					</button>
				</h2>
				<div id="collapse03" class="accordion-collapse collapse" data-bs-parent="#myAccordion">
					<div class="card-body" style="color:navy;">
					<p>If you are on a construction project that uses ISO 15926 or CFIHOS or JIP33 (these standards are aligned), 
					you <b>should</b> just add your class in <b>your</b> own RDL (spreadsheet of database) and work on. 
					Our workflow procedures will take time that you might not have.
					Send your changes to your Data Governance person in your company, who will start the procedure with us.
					</p>
					<p>
					Notice we intend to enter your proposed data pretty fast (albeit volunteers), so changes will be soon in http://data.15926.org/rdl whan you ask us, but when we submit our changes to 
					POSC Caesar (months) who in turn will propose them to ISO (years). 
					</p>
					<p>
					For now, email the current (2024) ISO 15926-4 project leader: Onno PAAP onno.paap@gmail.com
					</p>
					</div>
				</div>
			</div>
			<div class="accordion-item">
				<h2 class="accordion-header" id="heading04">
					<button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#collapse04">
						4. Who is behind RDL2?
					</button>
				</h2>
				<div id="collapse04" class="accordion-collapse collapse" data-bs-parent="#myAccordion">
					<div class="card-body" style="color:navy;">
						<p>The work behind RDL2 is at the moment done by MRAIL. This acronym stands for Main RDL Action Item List. We say "at the moment" because the MRAIL team is the support of RDL2. But is was made by more than 50 companies, organized by the associations USPI and POSC Caesar. That work started in 1992. Only since 2008 the RDL became an online Semantic Web Ontology (Knowledge Graph), but it was online much longer. </p>
						<p>MRAIL is a Special Interest Group (SIG) of POSC Caesar.</p>
						<p>Contact:</p>
						<li>POSC Caesar: &quot;Nils Sandsmark (NO)&quot; &lt;nils.sandsmark@posccaesar.org&gt;</li>
						<li>MRAIL: &quot;Onno Paap (NL)&quot; &lt;onno.paap@protonmail.com&gt;</li>
						<p />
						<p>Special credit to:</p>
						<li>Hans Teijgeler (won the Polar Bear award of POSC Caesar for RDL2)</li>
						<li>Andrew Prosser</li>
						<li>Arto Marttinen</li>
						<li>Dennis Lacey</li>
						<li>Dirk Walther</li>
						<li>Duhwan Mun</li>
						<li>Erik Molin</li>
						<li>Franz Schulze</li>
						<li>Heiner Temmen</li>
						<li>Hindrik Koning</li>
						<li>Ian Glendinning</li>
						<li>Jon Rustand</li>
						<li>Onno Paap</li>
						<li>Keith Willshaw</li>
						<li>Magne Valen-Sendstad</li>
						<li>Nils Sandsmark</li>
						<li>Peter Townson</li>
						<li>Robert Skaar</li>
						<li>Robin Benjamins</li>
						<li>Rowen Rathling</li>
						<li>Victor Agroskin</li>
					</div>
				</div>
			</div>
			<div class="accordion-item">
				<h2 class="accordion-header" id="heading05">
					<button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#collapse05">
						5. License for use
					</button>
				</h2>
				<div id="collapse05" class="accordion-collapse collapse" data-bs-parent="#myAccordion">
					<div class="card-body" style="color:navy;">
						<h2>This 15926browser software</h2>
						<p>MIT license</p>
						<p>Permission is hereby granted, free of charge, to any person obtaining a copy
						of this software and associated documentation files (the "Software"), to deal
						in the Software without restriction, including without limitation the rights
						to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
						copies of the Software, and to permit persons to whom the Software is
						furnished to do so, subject to the following conditions:</p>
						<p>The above copyright notice and this permission notice shall be included in
						all copies or substantial portions of the Software.</p>
						<p>THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
						IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
						FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
						AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
						LIABILITY, WHhttp://190.92.134.58:8890/sparqlh2>
						<p>If you want to use the RDL commercially, it needs to be approved by POSC Caesar, who hold the copyright.<br>
						They will typically approve you the use for commercial purposes.<br> 
						They hold the copyright to prevent anybody else to claim copyright over it.
						</p>
					</div>
				</div>
			</div>
			<div class="accordion-item">
				<h2 class="accordion-header" id="heading06">
					<button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#collapse06">
						6. Sparql endpoint?
					</button>
				</h2>
				<div id="collapse06" class="accordion-collapse collapse" data-bs-parent="#myAccordion">
					<div class="card-body" style="color:navy;">
						<p>If you want to do your own Sparql queries, goto <a href="` + config.settings.queryAllEndpoint + `">` + config.settings.queryAllEndpoint + `</a></p>
					</div>
				</div>
			</div>
		</div>
		`
		$('#list').html(html);	

		var selected = "";
		var stringAfterLastSlash = config.endpoint.substring(config.endpoint.lastIndexOf("/")+1);
		for (var i of config.endpoints ) {
			selected = '';
			if ("http://data.15926.org/" + stringAfterLastSlash==i[1]) {
				selected='selected';
			}
			$("#endpoints").append('<option value="' + i[1] + '" ' + selected + '>' + i[0] + '</option>')
		}
	
		html="";
	}
}

interface ISparql {
	query: string;
	endpoint: string;
}
class Sparql implements ISparql {
	
	private _statement: string;
	private _type: string;
	private _seq: number;
	
	private _query: string;
	get query(): string {return this._query;}
	set query(query: string) {
		this._query=this.sanitize(query);
	}

	private _endpoint: string;
	get endpoint(): string {return this._endpoint;}
	set endpoint(endpoint: string) {
		this._endpoint=this.sanitize(endpoint);
	}
	
	private tagBody: string = `(?:[^"'>]|"[^"]*"|'[^']*')*`;

	private tagOrComment: any = new RegExp(
	    '<(?:'
	    // Comment body.
	    + '!--(?:(?:-*[^->])*--+|-?)'
	    // Special "raw text" elements whose content should be elided.
	    + '|script\\b' + this.tagBody + '>[\\s\\S]*?</script\\s*'
	    + '|style\\b' + this.tagBody + '>[\\s\\S]*?</style\\s*'
	    // Regular name
	    + '|/?[a-z]'
	    + this.tagBody
	    + ')>',
	    'gi'
	);

	sanitize (html) {
		var oldHtml;
		//script, style or comment 
		do {
			oldHtml = html;
			html = html.replace(this.tagOrComment, '');
		} while (html !== oldHtml);
		// < sign
		html=html.replace(/</g, '&lt;');

		return html;
	}

	buildstatement () {
		//build query entry
		var queryItems=this.filterStatement();
		//build sparql
		if (this._type=='wildcardtext') {
			this._statement=`
				select distinct ?text ?uri ?depr ('list' as ?mode) {
				{
					?uri rdfs:label ?text .				
					` + queryItems + `
					optional {?uri <http://data.15926.org/meta/valDeprecationDate> ?depr}
				} union {
					?uri rdfs:label ?x .				
					optional {?uri <http://data.15926.org/meta/valDeprecationDate> ?depr}
					{graph ?x974{
						?uri <http://www.w3.org/2004/02/skos/core#altLabel> ?text .				
						` + queryItems + `
						optional {graph ?x733{?uri <http://data.15926.org/meta/valDeprecationDate> ?depr}}
				}}}}
				order by lcase(?text)
			`;
		}
		if (this._type=='title') {
			this._statement=`
				select distinct ?text ?uri ?depr ('title' as ?mode) {
				{graph ?x194 {?uri rdfs:label ?text}} .
				filter (?uri=<$var>) .
				optional {?uri <http://data.15926.org/meta/valDeprecationDate> ?depr}
				} order by ?text
			`;
			//this._statement=this._statement.replace('$var',this._endpoint + '/' + this._query);
			this._statement=this._statement.replace('$var',this._query);
		}
		if (this._type=='otherpreds') {
			this._statement=`
				select distinct ?text ?object ?depr ?pred ('attribs' as ?mode) {
				{
				?s ?pred ?object .
				filter (?s=<$var>) .
				filter (?pred!=rdfs:label) .
				optional {graph ?x194 {?object rdfs:label ?text}} .
				optional {?s <http://data.15926.org/meta/valDeprecationDate> ?depr} .
				} 
				union 
				{graph ?x196 {
				?s ?pred ?object .
				filter (?s=<$var>) .
				optional {graph ?x184 {?object rdfs:label ?text}} .
				optional {?s <http://data.15926.org/meta/valDeprecationDate> ?depr} .
				}}
				values (?pred ?order_) {
				( <http://www.w3.org/2002/07/owl#sameAs> 1 )
				( <http://www.w3.org/2004/02/skos/core#altLabel> 2 )
				( <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> 3 )
				( <http://www.w3.org/2000/01/rdf-schema#subClassOf> 4 )
				( <http://www.w3.org/2004/02/skos/core#definition> 5)
				( <http://purl.org/dc/elements/1.1/Source> 6 )
				( <http://data.15926.org/prov/idISO> 7 )
				( <http://data.15926.org/prov/idCFIHOS> 8 )
				( <http://data.15926.org/prov/idPCA> 9 )
				( <http://data.15926.org/prov/statusPCA> 10 )
				( <http://purl.org/dc/terms/creator> 11 )
				( <http://www.w3.org/2004/02/skos/core#note> 12 )
				( <http://www.w3.org/2004/02/skos/core#changeNote> 13 )
				( <http://data.15926.org/prov/adminNote> 14 )
				( <http://www.w3.org/2004/02/skos/core#example> 15 )
				( <http://data.15926.org/meta/valEffectiveDate> 16 )
				( <http://data.15926.org/meta/valDeprecationDate> 17 )
				}} order by ?order_ ?pred ?object	
			`;
			//this._statement=this._statement.split('$var').join(this._endpoint + '/' + this._query);
			this._statement=this._statement.split('$var').join(this._query);
		}
		if (this._type=='relationsonto') {
			this._statement=`
				select ?text ?object ?depr ?pred ('revattribs' as ?mode) {graph ?x633 {
				?object ?pred ?s .
				filter (?s=<$var>) .
				optional {graph ?x194 {?object rdfs:label ?text}} .
				optional {?object <http://data.15926.org/meta/valDeprecationDate> ?depr} .
				filter (!contains(str(?object),'http://data.15926.org/tip/'))
				filter (!contains(str(?object),'http://data.15926.org/tpl/'))
				}} order by ?text ?object
			`;
			//this._statement = this._statement.replace('$var',this._endpoint + '/' + this._query);
			this._statement = this._statement.replace('$var',this._query);
		}
		
		this._statement=this._statement.replace(/(\r\n|\n|\r|\t)/gm," ");
		this._statement=this._statement.replace(/  /g," ");
	}
	
	filterStatement () {
        //uses query to build a Openlink Virtuoso bif:contains string
        var queryItems = this._query;
        queryItems = queryItems.trim();
        //NOTE: fn:upper-case CAUSES THE DATABASE TO CRASH IF THERE IS INDEED A CLASS THAT IS NOT UPPERCASE
        // if (queryItems.indexOf(" ") == -1) {
        // 	queryItems = `filter contains(fn:upper-case(str(?text)),fn:upper-case("` + queryItems + `")) . `;
        // } else {
        queryItems = queryItems.replace(/  /g, ' ');
        queryItems = queryItems.trim();
        queryItems = queryItems.replace(/--/g, '-');
        queryItems = queryItems.replace(/-/g, ' ');
        //queryItems = "'" + queryItems + "'";
        //queryItems = queryItems.replace(/ /g, "' '");
        //queryItems = queryItems.replace(/ /g, ' and ');
        //queryItems = "?text <bif:contains> \"" + queryItems + "\"";

		//check for the RDS numbers (example rdl:RDS16765614 )
		if (queryItems.indexOf(':')>0) {
			queryItems = queryItems.substring(queryItems.lastIndexOf(':') + 1)
		}
		
		if (config.searchLiteral) {
			queryItems = "filter (lcase(str(?text)) = lcase('" + queryItems + "'))";
		} else {
			queryItems = " " + queryItems + " ";
			queryItems = queryItems.replace(/ /g, '%');
			queryItems = "filter (lcase(str(?text)) like lcase('" + queryItems + "') or str(?uri) like '" + queryItems + "' )";
		}

        // }
        return queryItems;
	}
	

	exec (type, seq?) {
		this._type=type;
		if (seq) {
			this._seq=seq;
		} else {
			this._seq=1;
		}
		
		
		//is endpoint set?	is query entered? is type set?
		if (this._endpoint > ' ' && this._query > ' ' && this._type > ' ') {

			this.buildstatement();
			
			//testing...
			//var	fullQuery = this._endpoint.replace('data.15926.org','localhost/data') + "?query=" + encodeURIComponent(this._statement) + "&format=json";
			var fullQuery = config.settings.queryAllEndpoint;
			if (this._type in ["relationsonto","otherpreds"]) {
				//all namespaces
				fullQuery = fullQuery + "?query=" + encodeURIComponent(this._statement) + "&format=json";
			} else if (this._endpoint.indexOf("/all") > -1) {
				//all namespaces
				fullQuery = fullQuery + "?query=" + encodeURIComponent(this._statement) + "&format=json";
			} else if (this._endpoint.indexOf("/rdl") > -1) {
				// namespace rdl + dm + lci
				fullQuery = fullQuery + "?default-graph-uri=" + encodeURIComponent("http://data.15926.org/rdl") + "&default-graph-uri=" + encodeURIComponent("http://data.15926.org/dm") + "&default-graph-uri=" + encodeURIComponent("http://data.15926.org/prov") + "&default-graph-uri=" + encodeURIComponent("http://data.15926.org/lci") + "&query=" + encodeURIComponent(this._statement) + "&format=json";
			} else {
				// specific other namespace
				var defaultgraph = this._endpoint;
				defaultgraph = defaultgraph.replace('https', 'http');
				defaultgraph = defaultgraph.replace('data.', 'data.');
				fullQuery = fullQuery + "?default-graph-uri=" + encodeURIComponent(defaultgraph) + "&query=" + encodeURIComponent(this._statement) + "&format=json";
			}
			$.ajax({
				url: fullQuery,
				dataType: 'jsonp',
				jsonp: 'callback',
				success: function(data)	{
					writer.results (data, seq);
				},
				error: function(data)	{
					writer.error (data, seq, fullQuery);
				},
			});

			$('#list').html('Working...');
		}	
	}

}

interface IWriter {
}
class Writer implements IWriter {
	
	private rec: any;
	private _table = [ { seq: 0, html: '<table>'} ];
	
	tablereset () {
		this._table = [ { seq: 0, html: '<table>'}, { seq: Number.MAX_VALUE, html: '</table>'} ];
	}
	
	compare(a,b) {
	  if (a.seq < b.seq)
	    return -1;
	  if (a.seq > b.seq)
	    return 1;
	  return 0;
	}
	
	results (data: any, seq: number) {

		var html, mode, uri, depr, text, object, objectType, pred, buttons, clipit :string;
		var obj:any;
		var counts;
		var loc = window.location.href;
		var dir = loc.substring(0, loc.lastIndexOf('/')); 
		if (dir.indexOf("/15926browser")==-1) dir = dir + "/15926browser";

		counts = data.results.bindings.length;
		if (counts>0) {
			for	(var i = 0;	i <	data.results.bindings.length; i++) {
				html = mode = uri = depr = text = object = objectType = pred = buttons = undefined;

				obj = data.results.bindings[i];
				if (typeof obj.mode !== 'undefined') mode = obj.mode.value;
				if (typeof obj.uri !== 'undefined') uri = obj.uri.value;
				if (typeof obj.depr !== 'undefined') depr = obj.depr.value;
				if (typeof obj.pred !== 'undefined') pred = obj.pred.value;
				if (typeof obj.text !== 'undefined') text = obj.text.value;
				if (typeof obj.object !== 'undefined') {
					object = obj.object.value;
					objectType = obj.object.type;
				}

				if (depr == undefined || (depr !== undefined && config.includedeprecated)) {
				
					buttons=`
					<div style="float:right" class="btn-group py-1" role="group">
						<button id="copyID" title="Copy ID to clipboard" data-clipboard-target="#linkedDataID" type="button" data-toggle="tooltip" class="btn btn-sm btn-outline-primary py-0" style="font-size: 0.8em;"><i class="bi-clipboard"></i> </button>
						<button id="copyFractionID"  title="Copy last part of ID to clipboard" type="button" data-toggle="tooltip" class="btn btn-sm btn-outline-primary py-0" style="font-size: 0.8em;"><i class="bi-clipboard-data"></i> </button>
						<a href="${dir}/export/index.html?id=${uri}" target="_new" title="Taxonomy starting at this id to spreadsheet" type="button" data-toggle="tooltip" class="btn btn-sm btn-outline-primary py-0" style="font-size: 0.8em;"><i class="bi-table"></i> </a>
					</div>
					`;
			
					clipit=`
					<div style="float:right;" class="btn-group py-1" role="group">
						<button id="clipit" title="Copy text to clipboard" type="button" data-toggle="tooltip" class="btn btn-sm btn-outline-primary py-0" style="font-size: 0.7em;padding:2px"><i class="bi-clipboard"></i> </button>
					</div>
					`;
			
					if (depr !== undefined) {
						text = '<span class="deprecated">' + text + '</span>';
					}
					
					//layout to versioninfo
    
					if (mode=='list') {
						if (counts == 1) {
							command.do("new", "object", "object", uri );
						} else {
							html = '<tr><td class="data"><a href=\'javascript:command.do("new", "object", "object", "' + uri + '");\' >' + text + '</a></td></tr>';
							this._table.push( {seq: 100000 * seq + i, html: html} );
						}
					}
					
					if (mode=='title') {

						html = `<div id="title">
						<tr><td colspan="2" class="title">${text}</td></tr>
						<!-- <tr><td /><td id="infodialog" style="color:red; weight:bold;"></td></tr> -->
						<tr><td class="prompt">id</td><td class="data" id="linkedDataID">${uri}${buttons}</td>
						</tr>
						<tr><td class="prompt">rdfs:label</td><td class="data">${text}</td></tr>
						</div>`;
						
						this._table.push( {seq: 100000 * seq + i, html: html} );

						$(document).on('click', '#copyID', function() {
							//copy whole linked data address to clipboard 
							var fullid = document.getElementById("linkedDataID");
							var text = fullid.innerText;
							copytoclipboard(text);
							var html = fullid.innerHTML;
							fullid.innerHTML = html.replace(text, "<span id='thetext'>" + text + "</span>");
							var thetextid = document.getElementById("thetext");
							thetextid.style.backgroundColor='black';
							thetextid.style.color='white';
							setTimeout(function() {fullid.innerHTML = html;},1000);
						});
						$(document).on('click', '#copyFractionID', function() {
							//copy part of linked data address after its last slash to clipboard 
							var fullid = document.getElementById("linkedDataID");
							var text = /[^/]*$/.exec(fullid.innerText)[0];
							copytoclipboard(text);
							var html = fullid.innerHTML;
							fullid.innerHTML = html.replace(text, "<span id='thetext'>" + text + "</span>");
							var thetextid = document.getElementById("thetext");
							thetextid.style.backgroundColor='black';
							thetextid.style.color='white';
							setTimeout(function() {fullid.innerHTML = html;},1000);
						});
					}
					
					if (mode=='attribs' || mode=='revattribs') {
						if (objectType=='uri') {
							if (typeof obj.text !== 'undefined') {
								text='<a href=\'javascript:command.do("new", "object", "object", "' + object + '");\'>' + text + '</a>'; 
							} else if (obj.pred.value=='http://www.w3.org/2002/07/owl#sameAs') {
								text='<a href=\'' + object + '\' target=\'_blank\'>' + object + '</a>'; 
							} else {
								text='<a href=\'javascript:command.do("new", "object", "object", "' + object + '");\'>' + config.namespace(object) + '</a>';
							}
						} else {
							text=object;
						}
						pred = config.namespace(pred);
					}
					
					if (mode=='attribs') {
						if 	(	pred.startsWith('prov:') || 
								pred.startsWith('dcterms:') ||
								pred.startsWith('meta:') || 
								pred.startsWith('skos:note')
							) {
							if (config.includeprovenance) {
								html = '</tr><tr><td class="prompt">' + pred + '</td><td class="data">' + text + '</td></tr>';
								this._table.push( {seq: 100000 * seq + i, html: html} );
							}
						} else {
							html = '</tr><tr><td class="prompt">' + pred + '</td><td class="data">' + text + '</td></tr>';
							this._table.push( {seq: 100000 * seq + i, html: html} );
						}
					}

					if (mode=='revattribs') {
						if (pred=='rdfs:subClassOf') {
							pred = 'Superclass for';	
						} else {
							pred = 'is ' + pred.substring(pred.indexOf(':')+1) + ' for';
						}					
						html = '</tr><tr><td class="prompt">' + pred + '</td><td class="data">' + text + '</td></tr>';
						this._table.push( {seq: 100000 * seq + i, html: html} );
					}

				}
			}
				
			//sort the result and display
			this._table.sort(this.compare);
			html='';
			for(var key in this._table) {
				html += this._table[key].html;
			}
			$('#list').html(html);
			html='';
		} else {
			if ($('#list').html() == 'Working...') {
				$('#list').html('Nothing found');
			}
		}
		
	}
	error (data: any, seq: number, fullQuery: string) {
		var query = decodeURIComponent(fullQuery);
		query = query.split("}").join("}<br />");
		query = query.split("{").join("<br />{")
		query = query.split("select").join("<br />select")
		var errortext = `
		<div class="alert alert-danger d-flex align-items-center" role="alert">
			<svg class="bi flex-shrink-0 me-2" width="24" height="24" role="img" aria-label="Danger:"><use xlink:href="#exclamation-triangle-fill"/></svg>
			<div>
				<h4 class="alert-heading">Error</h4>
				<p>` + data.state() + ' ' + data.status + ' ' + data.statusText + `</p>
				<p><code>` + fullQuery + `</code></p>
				<hr />
				<p><code>` + query + `</code></p>
			</div>
		</div>
		`
		$('#list').html(errortext);
	}
	
}

function copytoclipboard(text) {
	let textArea = document.createElement("textarea");
	textArea.value = text;
	// make the textarea out of viewport
	textArea.style.position = "fixed";
	textArea.style.left = "-999999px";
	textArea.style.top = "-999999px";
	document.body.appendChild(textArea);
	textArea.focus();
	textArea.select();
	// have to use execCommand instead of writeText because no https yet on this site
	document.execCommand('copy');
	textArea.remove();
};
