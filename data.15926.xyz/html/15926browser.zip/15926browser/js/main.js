/************************************
/* main.ts
 * This is the RDL2 browser
 * belongs at address http://data.15926.xyz
 * By Onno Paap
 * 25 March 2025
 * onno.paap@protonmail.com
 * License: MIT
 * how to compile:
 
cd "D:\SynologyDriveWindows\repos\docker\data.15926.xyz\html\15926browser\js"

tsc -t es5 main.ts
 
 ***********************************/
var config, temp, sparql, writer, command;
;
var Config = /** @class */ (function () {
    function Config() {
        this.settings = {
            // CHANGE THE REAL LOCATION OF THE BROWSER ONLY IN THESE 2 SETTINGS
            defaultNamedGraph: 'https://standards.iso.org/iso/15926/-4/reference-data-item',
            queryEndpoint: 'https://data.15926.xyz/sparql',
        };
        this._namespaces_short = [["xsd:", "http://www.w3.org/2001/XMLSchema#"],
            ["fn:", "http://www.w3.org/2005/xpath-functions#"],
            ["fn:", "http://www.w3.org/2005/xpath-functions/#"],
            ["meta:", "http://data.15926.org/meta/"],
            ["owl:", "http://www.w3.org/2002/07/owl#"],
            ["prov:", "http://data.15926.org/prov/"],
            ["rdf:", "http://www.w3.org/1999/02/22-rdf-syntax-ns#"],
            ["rdfa:", "http://www.w3.org/ns/rdfa#"],
            ["rdfs:", "http://www.w3.org/2000/01/rdf-schema#"],
            ["skos:", "http://www.w3.org/2004/02/skos/core#"],
            ["dcterms:", "http://purl.org/dc/terms/"],
            ["dcelem:", "http://purl.org/dc/elements/1.1/"]
        ];
        this._namespaces = [["ISO 15926-4", "https://standards.iso.org/iso/15926/-4/reference-data-item"]
        ];
        //if not given in the current address, use the default graph
        if (this._namedGraph == undefined)
            this._namedGraph = this.settings.defaultNamedGraph;
        // define the includedeprecated as false
        if (this._includedeprecated == undefined)
            this._includedeprecated = false;
        // define the includeprovenance as false
        if (this._includeprovenance == undefined)
            this._includeprovenance = false;
        // define the searchLiteral as false
        if (this._searchLiteral == undefined)
            this._searchLiteral = false;
    }
    Object.defineProperty(Config.prototype, "graph", {
        get: function () { return this._namedGraph; },
        set: function (http) {
            this._namedGraph = http;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Config.prototype, "includedeprecated", {
        get: function () { return this._includedeprecated; },
        set: function (status) {
            this._includedeprecated = status;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Config.prototype, "includeprovenance", {
        get: function () { return this._includeprovenance; },
        set: function (status) {
            this._includeprovenance = status;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Config.prototype, "searchLiteral", {
        get: function () { return this._searchLiteral; },
        set: function (status) {
            this._searchLiteral = status;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Config.prototype, "graphs", {
        get: function () { return this._namespaces; },
        enumerable: false,
        configurable: true
    });
    Config.prototype.namespace = function (uri) {
        for (this._i = 0; this._i < this._namespaces_short.length; this._i++) {
            uri = uri.replace(this._namespaces_short[this._i][1], this._namespaces_short[this._i][0]);
        }
        return uri;
    };
    return Config;
}());
$(document).ready(function () {
    config = new Config();
    sparql = new Sparql();
    writer = new Writer();
    command = new Command();
    //if changing an graph on the dropdown
    $("#graphs").change(function () {
        config.graph = $("#graphs").val();
    });
    //activate include deprecated switch
    //$("#includedeprecated").prop("checked", config.includedeprecated);
    //$("#includedeprecated").click(function( event ) {
    //	config.includedeprecated = $("#includedeprecated").prop("checked");
    //});
    //activate include provenance switch
    //$("#includeprovenance").prop("checked", config.includeprovenance);
    //$("#includeprovenance").click(function( event ) {
    //	config.includeprovenance = $("#includeprovenance").prop("checked");
    //});
    config.includeprovenance = true;
    //activate include provenance switch
    $("#searchLiteral").prop("checked", config.searchLiteral);
    $("#searchLiteral").click(function (event) {
        config.searchLiteral = $("#searchLiteral").prop("checked");
    });
    //forward and back history click
    window.onpopstate = function (event) {
        if (event.state == null) {
            command.do('history', 'search', null, null, null);
        }
        else {
            command.do('history', event.state.layoutview, event.state.doCommand, event.state.val1, event.state.val2);
        }
    };
    //initialize history state
    window.history.pushState({ query: '' }, '', '');
    //check if this is a direct address to be displayed
    var id = window.location.href;
    if (id.substring(-1) == '/' || id.substring(-1) == '#') {
        id = id.substring(0, id.length - 1);
    }
    // ISO Smart 
    id = id.replace('data.15926.xyz', 'standards.iso.org');
    //check if the last part of the address is a namespace or something longer, like an ID or a query
    var endp = "";
    for (var _a = 0, _b = config.graphs; _a < _b.length; _a++) {
        var i = _b[_a];
        if (i[1] == id.substring(0, i[1].length)) {
            endp = i[1];
        }
    }
    if (endp.length > 5) {
        config.graph = endp;
    }
    else {
        config.graph = config.settings.defaultNamedGraph;
    }
    if (id.length > endp.length) {
        //so id is not a namespace, now assume its a complete id to be retrieved, e.g. 
        // https://data.15926.org/15926browser?id=http://data.15926.org/rdl/RDS267929
        command.do('new', 'object', 'object', id, endp);
    }
    //graphs in settings
    var selected = '';
    var stringAfterLastSlash = config.graph.substring(config.graph.lastIndexOf("/") + 1);
    for (var _c = 0, _d = config.graphs; _c < _d.length; _c++) {
        var i = _d[_c];
        selected = '';
        if ("https://data.15926.org/" + stringAfterLastSlash == i[1]) {
            selected = 'selected';
        }
        $("#graphs").append('<option value="' + i[1] + '" ' + selected + '>' + i[0] + '</option>');
    }
    //activate execute a search
    $("#search").keydown(function (event) {
        if (event.which == 13) {
            event.preventDefault();
            //run query
            command.do('new', 'query', 'wildcardquery', command.validate($("#search").val()), config.graph);
        }
    });
    $("#info").click(function (event) {
        var info = new Info();
    });
    //put cursor in searchbar
    $('#search').focus();
});
var Command = /** @class */ (function () {
    function Command() {
    }
    Command.prototype.do = function (mode, layoutview, doCommand, val1, val2) {
        if (val1 == undefined) {
            val1 = "";
        }
        else {
            val1 = val1;
        }
        if (val2 == undefined) {
            val2 = val1.substring(0, val1.lastIndexOf("/"));
        }
        if (val1 > ' ') {
            //push state to history
            if (mode == 'new') {
                window.history.pushState({ "layoutview": layoutview, "doCommand": doCommand, "val1": val1, "val2": val2 }, '', '');
            }
            //run a command
            if (doCommand == 'wildcardquery') {
                sparql.query = val1;
                //$("#search").val(sparql.query);
                sparql.graph = val2;
                writer.tablereset();
                sparql.exec('wildcardtext', 1);
            }
            if (doCommand == 'object') {
                // a single address to be displayed
                writer.tablereset();
                sparql.query = val1;
                sparql.graph = val2;
                sparql.exec('title', 1);
                sparql.exec('otherpreds', 2);
                sparql.exec('relationsonto', 3);
            }
        }
    };
    Command.prototype.validate = function (val) {
        val = val.split('&').join("&amp;");
        val = val.split('"').join("");
        val = val.split("'").join("&#39;");
        val = val.split('<').join("&lt;");
        val = val.split('>').join("&gt;");
        return val;
    };
    return Command;
}());
var Info = /** @class */ (function () {
    function Info() {
        this.info();
    }
    Info.prototype.info = function () {
        var html = "\n\t\t<div class=\"accordion\" id=\"myAccordion\">\n\t\t\t<div class=\"accordion-item\">\n\t\t\t\t<h2 class=\"accordion-header\" id=\"heading01\">\n\t\t\t\t\t<button type=\"button\" class=\"accordion-button\" data-bs-toggle=\"collapse\" data-bs-target=\"#collapse01\">\n\t\t\t\t\t\t1. What is this ABOUT?\n\t\t\t\t\t</button>\t\t\t\t\t\t\t\t\t\n\t\t\t\t</h2>\n\t\t\t\t<div id=\"collapse01\" class=\"accordion-collapse collapse show\" data-bs-parent=\"#myAccordion\">\n\t\t\t\t\t<div class=\"card-body\" style=\"color:navy;\">\n\t\t\t\t\t\t<p>This is the search screen for RDL2.</p>\n\t\t\t\t\t\t<p>RDL stands for Reference Data Library. The RDL is an online Ontology and Thesaurus for the classes that are candidate to be used in the POSC Caesar Library, which in turn will set a core set of that candidate for standardization in ISO 15926-4.</p>\n\t\t\t\t\t\t<p>ISO 15926 is the data exchange and integration standard for the process industry. See this <a href=\"https://en.wikipedia.org/wiki/ISO_15926\">WIKIPEDIA article</a></p>\n\t\t\t\t\t</div>\n\t\t\t\t</div>\n\t\t\t</div>\n\t\t\t<div class=\"accordion-item\">\n\t\t\t\t<h2 class=\"accordion-header\" id=\"heading02\">\n\t\t\t\t\t<button type=\"button\" class=\"accordion-button collapsed\" data-bs-toggle=\"collapse\" data-bs-target=\"#collapse02\">\n\t\t\t\t\t\t2. How does this WORK?\n\t\t\t\t\t</button>\n\t\t\t\t</h2>\n\t\t\t\t<div id=\"collapse02\" class=\"accordion-collapse collapse\" data-bs-parent=\"#myAccordion\">\n\t\t\t\t\t<div class=\"card-body\" style=\"color:navy;\">\n\t\t\t\t\t\t<p>In the drop down are the named graphs to search in. These are not subject areas, but separated by ownership. RDL is the main graph. It contains the core library; the process plant items and other classes like document types, events, mile stones, etc. There are about 23,000 of these classes. \n\t\t\t\t\t\t<p>Example classes to search for are PUMP, PIPE, TRANSMITTER, LAYOUT or ENGINEERING. All class names are always singular, never plural. </p>\n\t\t\t\t\t\t<p>There are also subject areas like PIPING and INSTRUMENTATION. Just search for SUBJECT AREA</p>\n\t\t\t\t\t\t<p>There are more than 30 graphs containing more than 70,000 classes. Main ones are:</p>\n\t\t\t\t\t\t<li>RDL - core library</li>\n\t\t\t\t\t\t<li>CFIHOS - the classes from the Capital Factilities Information Handover Spec. See <a href=\"https://www.jip36-cfihos.org/\">IOGP website</a></li>\n\t\t\t\t\t\t<li>DM and LCI - the top of the data model</li>\n\t\t\t\t\t\t<li>IEC - a mapping to the CDD, to make these classes FINDable (try searching: transmitter).</li>\n\t\t\t\t\t</div>\n\t\t\t\t</div>\n\t\t\t</div>\n\t\t\t<div class=\"accordion-item\">\n\t\t\t\t<h2 class=\"accordion-header\" id=\"heading03\">\n\t\t\t\t\t<button type=\"button\" class=\"accordion-button collapsed\" data-bs-toggle=\"collapse\" data-bs-target=\"#collapse03\">\n\t\t\t\t\t\t3. I spotted a problem / want to add a class / need to add a hundred classes for my process plant type?\n\t\t\t\t\t</button>\n\t\t\t\t</h2>\n\t\t\t\t<div id=\"collapse03\" class=\"accordion-collapse collapse\" data-bs-parent=\"#myAccordion\">\n\t\t\t\t\t<div class=\"card-body\" style=\"color:navy;\">\n\t\t\t\t\t<p>If you are on a construction project that uses ISO 15926 or CFIHOS or JIP33 (these standards are aligned), \n\t\t\t\t\tyou <b>should</b> just add your class in <b>your</b> own RDL (spreadsheet of database) and work on. \n\t\t\t\t\tOur workflow procedures will take time that you might not have.\n\t\t\t\t\tSend your changes to your Data Governance person in your company, who will start the procedure with us.\n\t\t\t\t\t</p>\n\t\t\t\t\t<p>\n\t\t\t\t\tNotice we intend to enter your proposed data pretty fast (albeit volunteers), so changes will be soon in http://data.15926.org/rdl whan you ask us, but when we submit our changes to \n\t\t\t\t\tPOSC Caesar (months) who in turn will propose them to ISO (years). \n\t\t\t\t\t</p>\n\t\t\t\t\t<p>\n\t\t\t\t\tFor now, email the current (2024) ISO 15926-4 project leader: Onno PAAP onno.paap@gmail.com\n\t\t\t\t\t</p>\n\t\t\t\t\t</div>\n\t\t\t\t</div>\n\t\t\t</div>\n\t\t\t<div class=\"accordion-item\">\n\t\t\t\t<h2 class=\"accordion-header\" id=\"heading04\">\n\t\t\t\t\t<button type=\"button\" class=\"accordion-button collapsed\" data-bs-toggle=\"collapse\" data-bs-target=\"#collapse04\">\n\t\t\t\t\t\t4. Who is behind RDL2?\n\t\t\t\t\t</button>\n\t\t\t\t</h2>\n\t\t\t\t<div id=\"collapse04\" class=\"accordion-collapse collapse\" data-bs-parent=\"#myAccordion\">\n\t\t\t\t\t<div class=\"card-body\" style=\"color:navy;\">\n\t\t\t\t\t\t<p>The work behind RDL2 is at the moment done by MRAIL. This acronym stands for Main RDL Action Item List. We say \"at the moment\" because the MRAIL team is the support of RDL2. But is was made by more than 50 companies, organized by the associations USPI and POSC Caesar. That work started in 1992. Only since 2008 the RDL became an online Semantic Web Ontology (Knowledge Graph), but it was online much longer. </p>\n\t\t\t\t\t\t<p>MRAIL is a Special Interest Group (SIG) of POSC Caesar.</p>\n\t\t\t\t\t\t<p>Contact:</p>\n\t\t\t\t\t\t<li>POSC Caesar: &quot;Nils Sandsmark (NO)&quot; &lt;nils.sandsmark@posccaesar.org&gt;</li>\n\t\t\t\t\t\t<li>MRAIL: &quot;Onno Paap (NL)&quot; &lt;onno.paap@protonmail.com&gt;</li>\n\t\t\t\t\t\t<p />\n\t\t\t\t\t\t<p>Special credit to:</p>\n\t\t\t\t\t\t<li>Hans Teijgeler (won the Polar Bear award of POSC Caesar for RDL2)</li>\n\t\t\t\t\t\t<li>Andrew Prosser</li>\n\t\t\t\t\t\t<li>Arto Marttinen</li>\n\t\t\t\t\t\t<li>Dennis Lacey</li>\n\t\t\t\t\t\t<li>Dirk Walther</li>\n\t\t\t\t\t\t<li>Duhwan Mun</li>\n\t\t\t\t\t\t<li>Erik Molin</li>\n\t\t\t\t\t\t<li>Franz Schulze</li>\n\t\t\t\t\t\t<li>Heiner Temmen</li>\n\t\t\t\t\t\t<li>Hindrik Koning</li>\n\t\t\t\t\t\t<li>Ian Glendinning</li>\n\t\t\t\t\t\t<li>Jon Rustand</li>\n\t\t\t\t\t\t<li>Onno Paap</li>\n\t\t\t\t\t\t<li>Keith Willshaw</li>\n\t\t\t\t\t\t<li>Magne Valen-Sendstad</li>\n\t\t\t\t\t\t<li>Nils Sandsmark</li>\n\t\t\t\t\t\t<li>Peter Townson</li>\n\t\t\t\t\t\t<li>Robert Skaar</li>\n\t\t\t\t\t\t<li>Robin Benjamins</li>\n\t\t\t\t\t\t<li>Rowen Rathling</li>\n\t\t\t\t\t\t<li>Victor Agroskin</li>\n\t\t\t\t\t</div>\n\t\t\t\t</div>\n\t\t\t</div>\n\t\t\t<div class=\"accordion-item\">\n\t\t\t\t<h2 class=\"accordion-header\" id=\"heading05\">\n\t\t\t\t\t<button type=\"button\" class=\"accordion-button collapsed\" data-bs-toggle=\"collapse\" data-bs-target=\"#collapse05\">\n\t\t\t\t\t\t5. License for use\n\t\t\t\t\t</button>\n\t\t\t\t</h2>\n\t\t\t\t<div id=\"collapse05\" class=\"accordion-collapse collapse\" data-bs-parent=\"#myAccordion\">\n\t\t\t\t\t<div class=\"card-body\" style=\"color:navy;\">\n\t\t\t\t\t\t<h2>This 15926browser software</h2>\n\t\t\t\t\t\t<p>MIT license</p>\n\t\t\t\t\t\t<p>Permission is hereby granted, free of charge, to any person obtaining a copy\n\t\t\t\t\t\tof this software and associated documentation files (the \"Software\"), to deal\n\t\t\t\t\t\tin the Software without restriction, including without limitation the rights\n\t\t\t\t\t\tto use, copy, modify, merge, publish, distribute, sublicense, and/or sell\n\t\t\t\t\t\tcopies of the Software, and to permit persons to whom the Software is\n\t\t\t\t\t\tfurnished to do so, subject to the following conditions:</p>\n\t\t\t\t\t\t<p>The above copyright notice and this permission notice shall be included in\n\t\t\t\t\t\tall copies or substantial portions of the Software.</p>\n\t\t\t\t\t\t<p>THE SOFTWARE IS PROVIDED \"AS IS\", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR\n\t\t\t\t\t\tIMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,\n\t\t\t\t\t\tFITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE\n\t\t\t\t\t\tAUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER\n\t\t\t\t\t\tLIABILITY, WHhttp://190.92.134.58:8890/sparqlh2>\n\t\t\t\t\t\t<p>If you want to use the RDL commercially, it needs to be approved by POSC Caesar, who hold the copyright.<br>\n\t\t\t\t\t\tThey will typically approve you the use for commercial purposes.<br> \n\t\t\t\t\t\tThey hold the copyright to prevent anybody else to claim copyright over it.\n\t\t\t\t\t\t</p>\n\t\t\t\t\t</div>\n\t\t\t\t</div>\n\t\t\t</div>\n\t\t\t<div class=\"accordion-item\">\n\t\t\t\t<h2 class=\"accordion-header\" id=\"heading06\">\n\t\t\t\t\t<button type=\"button\" class=\"accordion-button collapsed\" data-bs-toggle=\"collapse\" data-bs-target=\"#collapse06\">\n\t\t\t\t\t\t6. Sparql graph?\n\t\t\t\t\t</button>\n\t\t\t\t</h2>\n\t\t\t\t<div id=\"collapse06\" class=\"accordion-collapse collapse\" data-bs-parent=\"#myAccordion\">\n\t\t\t\t\t<div class=\"card-body\" style=\"color:navy;\">\n\t\t\t\t\t\t<p>If you want to do your own Sparql queries, goto <a href=\"" + config.settings.queryEndpoint + "\">" + config.settings.queryEndpoint + "</a></p>\n\t\t\t\t\t</div>\n\t\t\t\t</div>\n\t\t\t</div>\n\t\t</div>\n\t\t";
        $('#list').html(html);
        var selected = "";
        var stringAfterLastSlash = config.graph.substring(config.graph.lastIndexOf("/") + 1);
        for (var _a = 0, _b = config.graphs; _a < _b.length; _a++) {
            var i = _b[_a];
            selected = '';
            if ("http://data.15926.org/" + stringAfterLastSlash == i[1]) {
                selected = 'selected';
            }
            $("#graphs").append('<option value="' + i[1] + '" ' + selected + '>' + i[0] + '</option>');
        }
        html = "";
    };
    return Info;
}());
var Sparql = /** @class */ (function () {
    function Sparql() {
        this.tagBody = "(?:[^\"'>]|\"[^\"]*\"|'[^']*')*";
        this.tagOrComment = new RegExp('<(?:'
            // Comment body.
            + '!--(?:(?:-*[^->])*--+|-?)'
            // Special "raw text" elements whose content should be elided.
            + '|script\\b' + this.tagBody + '>[\\s\\S]*?</script\\s*'
            + '|style\\b' + this.tagBody + '>[\\s\\S]*?</style\\s*'
            // Regular name
            + '|/?[a-z]'
            + this.tagBody
            + ')>', 'gi');
    }
    Object.defineProperty(Sparql.prototype, "query", {
        get: function () { return this._query; },
        set: function (query) {
            this._query = this.sanitize(query);
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Sparql.prototype, "graph", {
        get: function () { return this._namedGraph; },
        set: function (graph) {
            this._namedGraph = this.sanitize(graph);
        },
        enumerable: false,
        configurable: true
    });
    Sparql.prototype.sanitize = function (html) {
        var oldHtml;
        //script, style or comment 
        do {
            oldHtml = html;
            html = html.replace(this.tagOrComment, '');
        } while (html !== oldHtml);
        // < sign
        html = html.replace(/</g, '&lt;');
        return html;
    };
    Sparql.prototype.buildstatement = function () {
        //build query entry
        var queryItems = this.filterStatement();
        //build sparql
        if (this._type == 'wildcardtext') {
            this._statement = "\n\t\t\t\tselect distinct ?text ?uri ?depr ('list' as ?mode) {\n\t\t\t\t{\n\t\t\t\t\t?uri rdfs:label ?text .\t\t\t\t\n\t\t\t\t\t" + queryItems + "\n\t\t\t\t\toptional {?uri <http://data.15926.org/meta/valDeprecationDate> ?depr}\n\t\t\t\t} union {\n\t\t\t\t\t?uri rdfs:label ?x .\t\t\t\t\n\t\t\t\t\toptional {?uri <http://data.15926.org/meta/valDeprecationDate> ?depr}\n\t\t\t\t\t{graph ?x974{\n\t\t\t\t\t\t?uri <http://www.w3.org/2004/02/skos/core#altLabel> ?text .\t\t\t\t\n\t\t\t\t\t\t" + queryItems + "\n\t\t\t\t\t\toptional {graph ?x733{?uri <http://data.15926.org/meta/valDeprecationDate> ?depr}}\n\t\t\t\t}}}}\n\t\t\t\torder by lcase(?text)\n\t\t\t";
        }
        if (this._type == 'title') {
            this._statement = "\n\t\t\t\tselect distinct ?text ?uri ?depr ('title' as ?mode) {\n\t\t\t\t{graph ?x194 {?uri rdfs:label ?text}} .\n\t\t\t\tfilter (?uri=<$var>) .\n\t\t\t\toptional {?uri <http://data.15926.org/meta/valDeprecationDate> ?depr}\n\t\t\t\t} order by ?text\n\t\t\t";
            //this._statement=this._statement.replace('$var',this._namedGraph + '/' + this._query);
            this._statement = this._statement.replace('$var', this._query);
        }
        if (this._type == 'otherpreds') {
            this._statement = "\n\t\t\t\tselect distinct ?text ?object ?depr ?pred ('attribs' as ?mode) {\n\t\t\t\t{\n\t\t\t\t?s ?pred ?object .\n\t\t\t\tfilter (?s=<$var>) .\n\t\t\t\tfilter (?pred!=rdfs:label) .\n\t\t\t\toptional {graph ?x194 {?object rdfs:label ?text}} .\n\t\t\t\toptional {?s <http://data.15926.org/meta/valDeprecationDate> ?depr} .\n\t\t\t\t} \n\t\t\t\tunion \n\t\t\t\t{graph ?x196 {\n\t\t\t\t?s ?pred ?object .\n\t\t\t\tfilter (?s=<$var>) .\n\t\t\t\toptional {graph ?x184 {?object rdfs:label ?text}} .\n\t\t\t\toptional {?s <http://data.15926.org/meta/valDeprecationDate> ?depr} .\n\t\t\t\t}}\n\t\t\t\tvalues (?pred ?order_) {\n\t\t\t\t( <http://www.w3.org/2002/07/owl#sameAs> 1 )\n\t\t\t\t( <http://www.w3.org/2004/02/skos/core#altLabel> 2 )\n\t\t\t\t( <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> 3 )\n\t\t\t\t( <http://www.w3.org/2000/01/rdf-schema#subClassOf> 4 )\n\t\t\t\t( <http://www.w3.org/2004/02/skos/core#definition> 5)\n\t\t\t\t( <http://purl.org/dc/elements/1.1/Source> 6 )\n\t\t\t\t( <http://data.15926.org/prov/idISO> 7 )\n\t\t\t\t( <http://data.15926.org/prov/idCFIHOS> 8 )\n\t\t\t\t( <http://data.15926.org/prov/idPCA> 9 )\n\t\t\t\t( <http://data.15926.org/prov/statusPCA> 10 )\n\t\t\t\t( <http://purl.org/dc/terms/creator> 11 )\n\t\t\t\t( <http://www.w3.org/2004/02/skos/core#note> 12 )\n\t\t\t\t( <http://www.w3.org/2004/02/skos/core#changeNote> 13 )\n\t\t\t\t( <http://data.15926.org/prov/adminNote> 14 )\n\t\t\t\t( <http://www.w3.org/2004/02/skos/core#example> 15 )\n\t\t\t\t( <http://data.15926.org/meta/valEffectiveDate> 16 )\n\t\t\t\t( <http://data.15926.org/meta/valDeprecationDate> 17 )\n\t\t\t\t}} order by ?order_ ?pred ?object\t\n\t\t\t";
            //this._statement=this._statement.split('$var').join(this._namedGraph + '/' + this._query);
            this._statement = this._statement.split('$var').join(this._query);
        }
        if (this._type == 'relationsonto') {
            this._statement = "\n\t\t\t\tselect ?text ?object ?depr ?pred ('revattribs' as ?mode) {graph ?x633 {\n\t\t\t\t?object ?pred ?s .\n\t\t\t\tfilter (?s=<$var>) .\n\t\t\t\toptional {graph ?x194 {?object rdfs:label ?text}} .\n\t\t\t\toptional {?object <http://data.15926.org/meta/valDeprecationDate> ?depr} .\n\t\t\t\t}} order by ?text ?object\n\t\t\t";
            //this._statement = this._statement.replace('$var',this._namedGraph + '/' + this._query);
            this._statement = this._statement.replace('$var', this._query);
        }
        this._statement = this._statement.replace(/(\r\n|\n|\r|\t)/gm, " ");
        this._statement = this._statement.replace(/  /g, " ");
    };
    Sparql.prototype.filterStatement = function () {
        //uses query to build a Openlink Virtuoso bif:contains string
        var queryItems = this._query;
        queryItems = queryItems.trim();
        //NOTE: fn:upper-case CAUSES THE DATABASE TO CRASH IF THERE IS INDEED A CLASS THAT IS NOT UPPERCASE
        // if (queryItems.indexOf(" ") == -1) {
        // 	queryItems = `filter contains(fn:upper-case(str(?text)),fn:upper-case("` + queryItems + `")) . `;
        // } else {
        queryItems = queryItems.replace(/  /g, ' ');
        queryItems = queryItems.trim();
        queryItems = queryItems.replace(/--/g, '-');
        queryItems = queryItems.replace(/-/g, ' ');
        //queryItems = "'" + queryItems + "'";
        //queryItems = queryItems.replace(/ /g, "' '");
        //queryItems = queryItems.replace(/ /g, ' and ');
        //queryItems = "?text <bif:contains> \"" + queryItems + "\"";
        //check for the RDS numbers (example rdl:RDS16765614 )
        if (queryItems.indexOf(':') > 0) {
            queryItems = queryItems.substring(queryItems.lastIndexOf(':') + 1);
        }
        if (config.searchLiteral) {
            queryItems = "filter (lcase(str(?text)) = lcase('" + queryItems + "'))";
        }
        else {
            queryItems = " " + queryItems + " ";
            queryItems = queryItems.replace(/ /g, '%');
            queryItems = "filter (lcase(str(?text)) like lcase('" + queryItems + "') or str(?uri) like '" + queryItems + "' )";
        }
        // }
        return queryItems;
    };
    Sparql.prototype.exec = function (type, seq) {
        this._type = type;
        if (seq) {
            this._seq = seq;
        }
        else {
            this._seq = 1;
        }
        //is graph set?	is query entered? is type set?
        if (this._namedGraph > ' ' && this._query > ' ' && this._type > ' ') {
            this.buildstatement();
            // specific named graph
            var fullQuery = config.settings.queryEndpoint + "?default-graph-uri=" + encodeURIComponent(this._namedGraph) + "&query=" + encodeURIComponent(this._statement) + "&format=json";
            $.ajax({
                url: fullQuery,
                dataType: 'jsonp',
                jsonp: 'callback',
                success: function (data) {
                    //alert("success:" + JSON.stringify(data));
                    writer.results(data, seq);
                },
                error: function (data) {
                    //alert("fail:" + JSON.stringify(data));
                    var temp = JSON.stringify(data);
                    if (temp.indexOf('responseText') !== -1) {
                        writer.results(data, seq);
                    }
                    else {
                        writer.error(data, seq, fullQuery);
                    }
                },
            });
            $('#list').html('Working...');
        }
    };
    return Sparql;
}());
var Writer = /** @class */ (function () {
    function Writer() {
        this._table = [{ seq: 0, html: '<table>' }];
    }
    Writer.prototype.tablereset = function () {
        this._table = [{ seq: 0, html: '<table>' }, { seq: Number.MAX_VALUE, html: '</table>' }];
    };
    Writer.prototype.compare = function (a, b) {
        if (a.seq < b.seq)
            return -1;
        if (a.seq > b.seq)
            return 1;
        return 0;
    };
    Writer.prototype.sanetize = function (data) {
        var temp = JSON.stringify(data);
        if (temp.indexOf('responseText') !== -1) {
            // the response came back with an error 404 but also with a perfect reply
            temp = temp.substring(temp.indexOf("{") + 1);
            temp = temp.substring(temp.indexOf("{"));
            temp = temp.replace(/\\"/g, '"');
            temp = temp.replace(/\\n/g, '');
            temp = temp.replace(/\\t/g, '');
            temp = temp.replace(')","status":404,"statusText":"Not Found"}', '');
            data = JSON.parse(temp);
        }
        return data;
    };
    Writer.prototype.results = function (data, seq) {
        var html, mode, uri, depr, text, object, objectType, pred, buttons, clipit;
        var obj;
        var counts;
        var loc = window.location.href;
        var dir = loc.substring(0, loc.lastIndexOf('/'));
        if (dir.indexOf("/15926browser") == -1)
            dir = dir + "/15926browser";
        data = writer.sanetize(data);
        counts = data.results.bindings.length;
        if (counts > 0) {
            for (var i = 0; i < data.results.bindings.length; i++) {
                html = mode = uri = depr = text = object = objectType = pred = buttons = undefined;
                obj = data.results.bindings[i];
                if (typeof obj.mode !== 'undefined')
                    mode = obj.mode.value;
                if (typeof obj.uri !== 'undefined')
                    uri = obj.uri.value;
                if (typeof obj.depr !== 'undefined')
                    depr = obj.depr.value;
                if (typeof obj.pred !== 'undefined')
                    pred = obj.pred.value;
                if (typeof obj.text !== 'undefined')
                    text = obj.text.value;
                if (typeof obj.object !== 'undefined') {
                    object = obj.object.value;
                    objectType = obj.object.type;
                }
                if (depr == undefined || (depr !== undefined && config.includedeprecated)) {
                    buttons = "\n\t\t\t\t\t<div style=\"float:right\" class=\"btn-group py-1\" role=\"group\">\n\t\t\t\t\t\t<button id=\"copyID\" title=\"Copy ID to clipboard\" data-clipboard-target=\"#linkedDataID\" type=\"button\" data-toggle=\"tooltip\" class=\"btn btn-sm btn-outline-primary py-0\" style=\"font-size: 0.8em;\"><i class=\"bi-clipboard\"></i> </button>\n\t\t\t\t\t\t<button id=\"copyFractionID\"  title=\"Copy last part of ID to clipboard\" type=\"button\" data-toggle=\"tooltip\" class=\"btn btn-sm btn-outline-primary py-0\" style=\"font-size: 0.8em;\"><i class=\"bi-clipboard-data\"></i> </button>\n\t\t\t\t\t\t<!--\t\t\t\t\t\n\t\t\t\t\t\t<a href=\"".concat(dir, "/export/index.html?id=").concat(uri, "\" target=\"_new\" title=\"Taxonomy starting at this id to spreadsheet\" type=\"button\" data-toggle=\"tooltip\" class=\"btn btn-sm btn-outline-primary py-0\" style=\"font-size: 0.8em;\"><i class=\"bi-table\"></i> </a>\n\t\t\t\t\t\t-->\n\t\t\t\t\t</div>\n\t\t\t\t\t");
                    clipit = "\n\t\t\t\t\t<div style=\"float:right;\" class=\"btn-group py-1\" role=\"group\">\n\t\t\t\t\t\t<button id=\"clipit\" title=\"Copy text to clipboard\" type=\"button\" data-toggle=\"tooltip\" class=\"btn btn-sm btn-outline-primary py-0\" style=\"font-size: 0.7em;padding:2px\"><i class=\"bi-clipboard\"></i> </button>\n\t\t\t\t\t</div>\n\t\t\t\t\t";
                    if (depr !== undefined) {
                        text = '<span class="deprecated">' + text + '</span>';
                    }
                    //layout to versioninfo
                    if (mode == 'list') {
                        if (counts == 1) {
                            command.do("new", "object", "object", uri);
                        }
                        else {
                            html = '<tr><td class="data"><a href=\'javascript:command.do("new", "object", "object", "' + uri + '");\' >' + text + '</a></td></tr>';
                            this._table.push({ seq: 100000 * seq + i, html: html });
                        }
                    }
                    if (mode == 'title') {
                        html = "<div id=\"title\">\n\t\t\t\t\t\t<tr><td colspan=\"2\" class=\"title\">".concat(text, "</td></tr>\n\t\t\t\t\t\t<!-- <tr><td /><td id=\"infodialog\" style=\"color:red; weight:bold;\"></td></tr> -->\n\t\t\t\t\t\t<tr><td class=\"prompt\">id</td><td class=\"data\" id=\"linkedDataID\">").concat(uri).concat(buttons, "</td>\n\t\t\t\t\t\t</tr>\n\t\t\t\t\t\t<tr><td class=\"prompt\">rdfs:label</td><td class=\"data\">").concat(text, "</td></tr>\n\t\t\t\t\t\t</div>");
                        this._table.push({ seq: 100000 * seq + i, html: html });
                        $(document).on('click', '#copyID', function () {
                            //copy whole linked data address to clipboard 
                            var fullid = document.getElementById("linkedDataID");
                            var text = fullid.innerText;
                            copytoclipboard(text);
                            var html = fullid.innerHTML;
                            fullid.innerHTML = html.replace(text, "<span id='thetext'>" + text + "</span>");
                            var thetextid = document.getElementById("thetext");
                            thetextid.style.backgroundColor = 'black';
                            thetextid.style.color = 'white';
                            setTimeout(function () { fullid.innerHTML = html; }, 1000);
                        });
                        $(document).on('click', '#copyFractionID', function () {
                            //copy part of linked data address after its last slash to clipboard 
                            var fullid = document.getElementById("linkedDataID");
                            var text = /[^/]*$/.exec(fullid.innerText)[0];
                            copytoclipboard(text);
                            var html = fullid.innerHTML;
                            fullid.innerHTML = html.replace(text, "<span id='thetext'>" + text + "</span>");
                            var thetextid = document.getElementById("thetext");
                            thetextid.style.backgroundColor = 'black';
                            thetextid.style.color = 'white';
                            setTimeout(function () { fullid.innerHTML = html; }, 1000);
                        });
                    }
                    if (mode == 'attribs' || mode == 'revattribs') {
                        if (objectType == 'uri') {
                            if (typeof obj.text !== 'undefined') {
                                text = '<a href=\'javascript:command.do("new", "object", "object", "' + object + '");\'>' + text + '</a>';
                            }
                            else if (obj.pred.value == 'http://www.w3.org/2002/07/owl#sameAs') {
                                text = '<a href=\'' + object + '\' target=\'_blank\'>' + object + '</a>';
                            }
                            else {
                                text = '<a href=\'javascript:command.do("new", "object", "object", "' + object + '");\'>' + config.namespace(object) + '</a>';
                            }
                        }
                        else {
                            text = object;
                        }
                        pred = config.namespace(pred);
                    }
                    if (mode == 'attribs') {
                        if (pred.startsWith('prov:') ||
                            pred.startsWith('dcterms:') ||
                            pred.startsWith('meta:') ||
                            pred.startsWith('skos:note')) {
                            if (config.includeprovenance) {
                                html = '</tr><tr><td class="prompt">' + pred + '</td><td class="data">' + text + '</td></tr>';
                                this._table.push({ seq: 100000 * seq + i, html: html });
                            }
                        }
                        else {
                            html = '</tr><tr><td class="prompt">' + pred + '</td><td class="data">' + text + '</td></tr>';
                            this._table.push({ seq: 100000 * seq + i, html: html });
                        }
                    }
                    if (mode == 'revattribs') {
                        if (pred == 'rdfs:subClassOf') {
                            pred = 'Superclass for';
                        }
                        else {
                            pred = 'is ' + pred.substring(pred.indexOf(':') + 1) + ' for';
                        }
                        html = '</tr><tr><td class="prompt">' + pred + '</td><td class="data">' + text + '</td></tr>';
                        this._table.push({ seq: 100000 * seq + i, html: html });
                    }
                }
            }
            //sort the result and display
            this._table.sort(this.compare);
            html = '';
            for (var key in this._table) {
                html += this._table[key].html;
            }
            $('#list').html(html);
            html = '';
        }
        else {
            if ($('#list').html() == 'Working...') {
                $('#list').html('Nothing found');
            }
        }
    };
    Writer.prototype.error = function (data, seq, fullQuery) {
        var errortext = "";
        var query = "";
        if (data.status == "404") {
            errortext = "Error: named graph queried is not in database, or database not found<br>\n\t\t\t<p><code>" + fullQuery + "</code></p>";
        }
        else {
            query = decodeURIComponent(fullQuery);
            query = query.split("}").join("}<br />");
            query = query.split("{").join("<br />{");
            query = query.split("select").join("<br />select");
            errortext = "\n\t\t\t<div class=\"alert alert-danger d-flex align-items-center\" role=\"alert\">\n\t\t\t\t<svg class=\"bi flex-shrink-0 me-2\" width=\"24\" height=\"24\" role=\"img\" aria-label=\"Danger:\"><use xlink:href=\"#exclamation-triangle-fill\"/></svg>\n\t\t\t\t<div>\n\t\t\t\t\t<h4 class=\"alert-heading\">Error</h4>\n\t\t\t\t\t<p>" + data.state() + ' ' + data.status + ' ' + data.statusText + "</p>\n\t\t\t\t\t<p><code>" + fullQuery + "</code></p>\n\t\t\t\t\t<hr />\n\t\t\t\t\t<p><code>" + query + "</code></p>\n\t\t\t\t</div>\n\t\t\t</div>\n\t\t\t";
        }
        $('#list').html(errortext);
    };
    return Writer;
}());
function copytoclipboard(text) {
    var textArea = document.createElement("textarea");
    textArea.value = text;
    // make the textarea out of viewport
    textArea.style.position = "fixed";
    textArea.style.left = "-999999px";
    textArea.style.top = "-999999px";
    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();
    // have to use execCommand instead of writeText because no https yet on this site
    document.execCommand('copy');
    textArea.remove();
}
;
