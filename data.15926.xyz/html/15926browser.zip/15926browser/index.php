<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, shrink-to-fit=no, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>15926browser</title>
    <!-- Bootstrap CSS -->
    <link href="<?php echo get_current_host(); ?>/css/bootstrap/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo get_current_host(); ?>/css/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="<?php echo get_current_host(); ?>/css/style.css" rel="stylesheet">
</head>
<body>
<body>
    <div class="ms-3 me-2 mt-3">
        <div class="container-fluid ">
            <div class="row mb-6">
<!--
                <div class="col-2">
                    <button id="info" type="button" class="btn btn-link btn-lg"><i class="bi-list"></i> </button>
                </div>
-->                
                <div class="col-2" style="height: 60px;">
                    <a href="#"><img src='<?php echo get_current_host(); ?>/img/logo-smart-light.svg' 
                        class="logo" title="15926browser" /></a>
                </div>
            </div>  
            <div class="input-group mb-3">
                <div class="input-group-text p-0">
                    <select class="form-select form-select-sm shadow-none bg-light border-0" id="graphs"></select>
                </div>
                <input type="text" class="form-control form-input" placeholder="Search here, e.g. PUMP" id="search">
            </div>
<!--
            <div class="row mb-6">
                <div class="col-2"></div>
                <div class="col-2">
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" id="includedeprecated" />
                        <label class="form-check-label" for="includedeprecated">
                            Deprecated objects
                        </label>
                    </div>
                </div>
                <div class="col-2">
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" id="includeprovenance" />
                        <label class="form-check-label" for="includeprovenance">
                            Provenance attributes
                        </label>
                    </div>
                </div>
-->               
                <div class="col-2">
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" id="searchLiteral" />
                        <label class="form-check-label" for="searchLiteral">
                            Search literal term
                        </label>
                    </div>
                </div>
            </div>
            <div class="m-4" id="list">
            </div>
        </div>
    </div>
    <!-- jQuery -->
    <script type="text/javascript" src="<?php echo get_current_host(); ?>/js/jquery/jquery.min.js?ver=v3.5.1" ></script>
    <!-- Bootstrap -->
    <script type="text/javascript" src="<?php echo get_current_host(); ?>/js/bootstrap/bootstrap.bundle.min.js?ver=v5.1.3" ></script>
    <!-- Clipboard -->
    <script type="text/javascript" src="<?php echo get_current_host(); ?>/js/clipboard/clipboard.min.js?ver=v2.0.8" ></script>
    <!-- Main App -->
    <script type="text/javascript" src="<?php echo get_current_host(); ?>/js/main.js?mainversion=20250326T1941" ></script>
</html>
<?php
function get_current_host() {
    // Get the full file path of the current script
    //$absolutePath = realpath(dirname(__FILE__));

    $host = $_SERVER['HTTP_HOST'];

    return "https://" . $host . "/15926browser";
}
?>

